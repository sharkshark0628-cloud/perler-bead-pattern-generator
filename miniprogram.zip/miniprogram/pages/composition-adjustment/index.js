﻿require("./index.ts");
