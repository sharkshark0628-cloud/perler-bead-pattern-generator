App<IAppOption>({
  globalData: {},
})

